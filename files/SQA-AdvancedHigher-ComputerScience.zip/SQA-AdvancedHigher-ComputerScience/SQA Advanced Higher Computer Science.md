# SQA Advanced Higher Computer Science



## Course Overview

### Assessment:

* Question Paper: 80 marks - 2 hours 30 minutes
* Project: 80 marks



## Course Content

**Software design and development** 

* Candidates develop knowledge, understanding, and advanced practical problem-solving skills in software design and development. 

* They do this by using appropriate software development environments. Candidates develop object-oriented programming and computational-thinking skills by analysing, designing, implementing, testing, and evaluating practical solutions and explaining how these modular programs work. 
* They use their knowledge of data types and constructs to create efficient programs to solve advanced problems. 

**Database design and development**

* Candidates develop knowledge, understanding, and advanced practical problem-solving skills in database design and development. 
* They do this through a range of practical tasks, using SQL to create and query relational databases. 
* Candidates apply computational-thinking skills to analyse, design, implement, test, and evaluate practical solutions, using a range of development tools. 
* Candidates apply interpretation skills to tasks involving some complex features in both familiar and new contexts. 

**Web design and development** 

* Candidates develop knowledge, understanding, and advanced practical problem-solving skills in web design and development. 
* They do this through a range of practicaland investigative tasks. 
* Candidates apply computational-thinking skills to analyse, design, implement, test, and evaluate practical solutions to web-based problems, using a range of development tools including HTML, Cascading Style Sheets (CSS) and PHP. 
* Candidates apply interpretation skills to tasks involving some complex features in both familiar and new contexts. 

**Computer systems** 

* This content is designed to be delivered in the context of the other areas of study and not as a stand-alone area of study.
* Candidates develop their understanding of how data is stored in hexadecimal form and how flags are used during the fetch-execute cycle. 
* They become aware of the environmental impact of data centres and the security risks of code injections.



## Programming Paradigms

How many programming paradigms are we learning in AH Computing this year?

>  Three

Name each of the paradigms which will be discussed. 

> Imperative, object-orientated, concurrent programming 

Imperative programming has 3 basic control structures. Name and describe them. 

> Sequence - one command is executed followed by another
>
> Selection - if a condition is true then one command is executed, else if that condition is false then a different condition is executed 
>
> Iteration - a command is executed a set number of times

How are variables used in imperative programming?

> Variables are used to store values which can have their values changed within the program and which can be passed as parameters to procedures and functions

What is the difference between a global and local variable?

> A local variable exists temporarily within a function or procedure. 
>
> A global variable exists whilst a program is running and can have its value changed anywhere within that program.

What is another name for Imperative programming?

> Procedural programming

What is the name for values passed between procedures?

> Parameters

What is the term used to describe commands being combined into blocks of self-contained code?

> Modules

Describe 2 advantages of this style of coding.

> Modules can be treated as separate sub programs which can be tested independently of the main program.
>
> Large programming projects will benefit from a modular approach as several prople can work on them at the same time, each one working on a different module. 

What is the name for the parameters listed in the 'call' line of a procedure or function?

> Actual

What is the name for the parameters listed in the opening line of a procedure or function?

> Formal

How is a function different from a procedure? 

> Function - a section of code which returns a value
>
> Procedure - a section of code which does not necessarily return a value (e.g. a sub procedure).

What is a module library?

> A module (or modules) which are saved so that they can be used in other programs. They are used in projects to reduce development time as the developer can reuse the code. 

What reason has object-orientated programming been introduced?

> Object orientation allows a program to be separated into blocks of related data and the operations which apply to that data. Linking the data and its operations together in this way allows it to be treated as a single entity and means that data can only be accessed by its associated operations. 

What is a 'single entity' referred to as in OO programming?

> An object

What is this 'single entity' made up of?

> Attributes and operations

